/*
┏━━━━━━━━━━━━━━━┓
┃     𝐉𝐀𝐌𝐄𝐒𝐓𝐄𝐂𝐇
┣━━━━━━━━━━━━━━━┛
┃whatsapp : +254785016388
┃owner : james
┃base : vimpire killer 
┃best friend : ibrahim / trashcore dev
┃helper : my brain😂😂
┃maintainer : james
┃deals : t.me/jamespydev
┃pterodactyl hosting buy from james dev
┗━━━━━━━━━━━━━━━┛ボボ*  
*/
global.prefix = ["/", "!", "?", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["584261160423"] 
global.namabot = '👑⃟༑༑𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1✪⃝⚔️'
//~~~~~~~~~ Setting ~~~~~~~~~~//
global.namach = "king smiles"
global.link = "https://whatsapp.com/channel/0029VbAqjwm1CYoTLEg7KR44"
global.idch = "120363297764334618@newsletter"
global.imgthumb = "https://files.catbox.moe/zf4i3d.jpg"
global.vidthumb = "https://files.catbox.moe/g095te.mp4"
//~~~~~~~~~ Setting Mess ~~~~~~~~~~//
global.mess = { 
owner: '*ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ᴜsᴇᴅ ᴏɴʟʏ ғᴏʀ ᴏᴡɴᴇʀs*',
premium: '*ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ᴜsᴇᴅ ᴏɴʟʏ ғᴏʀ ᴘʀᴇᴍɪᴜᴍ*',
succes: '*sᴜᴄᴄᴇssғᴜʟʟʏ*',
group: '*ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ᴏɴʟʏ ᴜsᴇᴅ ɪɴ ɢʀᴏᴜᴘ*',
admins: '*ᴛʜᴇ ʙᴏᴛ ᴍᴜsᴛ ʙᴇ ᴀᴅᴍɪɴ ᴏғ ᴛʜᴇ ɢʀᴏᴜᴘ*'
//======================
}
     //==========ᴘʀɪᴍɪs ʙᴀsᴇ==========
// ᴄʀᴇᴀᴛᴏʀ : ᴅs ᴘʀɪᴍɪs
// ᴛʏᴘᴇ : 100% ʙᴜɢ / 50% ʙᴏᴛ
// 2024-2025
//================