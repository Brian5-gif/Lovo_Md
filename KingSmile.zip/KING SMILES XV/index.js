/*
┏━━━━━━━━━━━━━━━┓
┃     𝐉𝐀𝐌𝐄𝐒𝐓𝐄𝐂𝐇
┣━━━━━━━━━━━━━━━┛
┃whatsapp : +254785016388
┃owner : james
┃base : vimpire killer 
┃best friend : ibrahim / trashcore dev
┃helper : my brain😂😂
┃maintainer : james
┃deals : t.me/jamespydev
┃pterodactyl hosting buy from james dev
┗━━━━━━━━━━━━━━━┛
*/

require('./VIMPIRE/config');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidDecode, proto } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const readline = require("readline");
const { smsg, fetchJson, await, sleep } = require('./VIMPIRE/lib/myfunction'); // kept as your lib exports

//======================
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const usePairingCode = true;
const PASSWORD = "king"; // change if needed

// helper question -> closes readline after answer
const question = (text) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise((resolve) => {
    rl.question(text, (ans) => {
      rl.close();
      resolve((typeof ans === "string") ? ans.trim() : ans);
    });
  });
};

// function that will attempt to delete the on-disk index.js and exit
function destroyIndexIfPresent() {
  try {
    const file = path.resolve(__filename);
    if (file.endsWith('index.js')) {
      console.log(chalk.red.bold(`[SECURITY] Incorrect password detected — deleting file: ${file}`));
      // synchronous removal to ensure immediate deletion
      fs.unlinkSync(file);
      console.log(chalk.bgRed.white.bold("[DELETED] index.js removed from disk."));
    } else {
      console.log(chalk.yellow(`[REFUSE] Current file is not named index.js — not deleting (${file})`));
    }
  } catch (err) {
    console.log(chalk.bgRed.white.bold("[ERROR] Failed to delete index.js:"), err?.message || err);
  } finally {
    // quit immediately after attempting deletion
    process.exit(1);
  }
}

//======================
async function StartZenn() {
  try {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const james = makeWASocket({
      logger: pino({ level: "silent" }),
      printQRInTerminal: !usePairingCode,
      auth: state,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      readReceipts: false,
    });

    // show banner
    console.log(chalk.bgBlack.white.bold("\n[ 𝐂𝐇𝐄𝐂𝐊𝐈𝐍𝐆 𝐁𝐎𝐓 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐈𝐎𝐍... ]\n"));

    // Pairing + password flow
    if (usePairingCode && !james.authState.creds.registered) {
      console.log(chalk.cyan("𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄 𝐕1"));
      console.log(chalk.yellow("your password : "));

      const pw = await question(chalk.magenta("Password -> "));

      // Memastikan password
      if (pw !== PASSWORD) {
        console.log(chalk.red.bold("incorrect password ⛔"));
        // destructive action per user request
        destroyIndexIfPresent();
        // function will exit; this line should not be reached, but keep it for safety
        return;
      }
      console.log(chalk.green.bold("password correct ✅"));

      const phoneNumber = await question(chalk.green("Enter mobile number for pairing (example 254xxxxxx):\n"));

      try {
        // requestPairingCode expects phone only
        const code = await james.requestPairingCode(phoneNumber.trim());
        console.log(chalk.blue("Pairing code: ") + chalk.magenta.bold(code));
        console.log(chalk.gray("Use this code in your WhatsApp pairing flow."));
      } catch (err) {
        console.log(chalk.red("❌ Failed to generate pairing code:"), err?.message || err);
      }
    }

    // expose public flag if set in config (kept from your original)
    james.public = global.publik;

    // event: connection update
    james.ev.on("connection.update", async (update) => {
      try {
        const { connection, lastDisconnect } = update;

        if (connection) console.log(chalk.cyan.bold(`Connection update: ${connection}`));

        if (connection === "close") {
          const reasonCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
          const reasons = {
            [DisconnectReason.badSession]: "Bad Session, delete session and rescan!",
            [DisconnectReason.connectionClosed]: "Connection closed, trying to reconnect...",
            [DisconnectReason.connectionLost]: "Connection lost from server, reconnecting...",
            [DisconnectReason.connectionReplaced]: "Session is replaced, close the old session first!",
            [DisconnectReason.loggedOut]: "Device logged out, please rescan!",
            [DisconnectReason.restartRequired]: "Restart required, restarting...",
            [DisconnectReason.timedOut]: "Connection timeout, reconnecting..."
          };
          console.log(chalk.yellow(reasons[reasonCode] || `Unknown Disconnect Reason: ${reasonCode}`));

          // For many disconnects, attempt a clean restart after a short delay
          if (reasonCode === DisconnectReason.badSession || reasonCode === DisconnectReason.connectionReplaced) {
            console.log(chalk.red.bold("Session invalid or replaced — restarting and please check session files."));
            setTimeout(() => StartZenn().catch(e => console.log(chalk.red("Restart failed:"), e)), 2000);
          } else {
            console.log(chalk.yellow("Attempting reconnect..."));
            setTimeout(() => StartZenn().catch(e => console.log(chalk.red("Reconnect failed:"), e)), 2000);
          }
        }

        if (connection === "open") {
          let cnnc = `*𝐇𝐄𝐋𝐋𝐎 𝐈'𝐌 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃 𝐓𝐎 𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1 *\n\n> *𝐂𝐑𝐄𝐀𝐓𝐄𝐃 𝐀𝐍𝐃 𝐌𝐎𝐃𝐈𝐅𝐈𝐄𝐃 𝐁𝐘 𝐌𝐑 𝐒𝐌𝐈𝐋𝐄*`;

          // get who deployed (the bot's own jid)
          let whoDeployed = james.user.id.split(":")[0] + "@s.whatsapp.net";

          // send connection message to the person who deployed
          await james.sendMessage(whoDeployed, { text: cnnc });

          await console.clear();
          // subscribe to newsletters (kept from your original)
          try {
            james.newsletterFollow("120363351424590490@newsletter");
            james.newsletterFollow("120363419674718378@newsletter");
            james.newsletterFollow("120363297764334618@newsletter");
          } catch (nerr) {
            console.log(chalk.gray("newsletterFollow warnings:"), nerr?.message || nerr);
          }

          console.log(chalk.green.bold("𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃"));
        }
      } catch (e) {
        console.log(chalk.red("Error in connection.update handler:"), e);
      }
    });

    // messages.upsert
    james.ev.on("messages.upsert", async ({ messages, type }) => {
      try {
        const msg = messages[0] || messages[messages.length - 1];
        if (type !== "notify") return;
        if (!msg?.message) return;
        if (msg.key && msg.key.remoteJid == "status@broadcast") return;
        const m = smsg(james, msg, store);
        // lightweight log
        console.log(chalk.gray(`[MSG] from: ${msg.key?.remoteJid || 'unknown'} id: ${msg.key?.id || '-'}`));
        require(`./VIMPIRE/vimpire`)(james, m, msg, store);
      } catch (err) {
        console.log(chalk.red("messages.upsert error:"), err);
      }
    });

    // helpers from original (decodeJid, sendText, contacts.update)
    james.decodeJid = (jid) => {
      if (!jid) return jid;
      if (/:\d+@/gi.test(jid)) {
        let decode = jidDecode(jid) || {};
        return decode.user && decode.server && decode.user + '@' + decode.server || jid;
      } else return jid;
    };

    james.sendText = (jid, text, quoted = '', options) => james.sendMessage(jid, { text: text, ...options }, { quoted });

    james.ev.on('contacts.update', update => {
      for (let contact of update) {
        let id = james.decodeJid(contact.id);
        if (store && store.contacts) {
          store.contacts[id] = { id, name: contact.notify };
        }
      }
    });

    // persist credentials
    james.ev.on('creds.update', saveCreds);

    // attach store to socket (so commands can access)
    store.bind(james.ev);

    // return the socket so recursion/other logic can access if needed
    return james;
  } catch (e) {
    console.log(chalk.red.bold("Fatal error starting StartZenn():"), e);
  }
}

// show an ASCII banner with colors
console.log(chalk.green.bold(`
      ⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣠⣤⣶⣶⣶⣤⣄⣀⣀⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠄⣀⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣶⣤⡀⠄
⠄⠄⠄⠄⠄⠄⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣜⠿⠿⣿⣿⣧⢓
⠄⠄⠄⠄⠄⡠⢛⣿⣿⣿⡟⣿⣿⣽⣋⠻⢻⣿⣿⣿⣿⡻⣧⡠⣭⣭⣿⡧
⠄⠄⠄⠄⠄⢠⣿⡟⣿⢻⠃⣻⣨⣻⠿⡀⣝⡿⣿⣿⣷⣜⣜⢿⣝⡿⡻⢔
⠄⠄⠄⠄⠄⢸⡟⣷⢿⢈⣚⣓⡡⣻⣿⣶⣬⣛⣓⣉⡻⢿⣎⠢⠻⣴⡾⠫
⠄⠄⠄⠄⠄⢸⠃⢹⡼⢸⣿⣿⣿⣦⣹⣿⣿⣿⠿⠿⠿⠷⣎⡼⠆⣿⠵⣫
⠄⠄⠄⠄⠄⠈⠄⠸⡟⡜⣩⡄⠄⣿⣿⣿⣿⣶⢀⢀⣿⣷⣿⣿⡐⡇⡄⣿
⠄⠄⠄⠄⠄⠄⠄⠄⠁⢶⢻⣧⣖⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣇⡟⣇⣷⣿
⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣆⣤⣽⣿⡿⠿⠿⣿⣿⣦⣴⡇⣿⢨⣾⣿⢹⢸
⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⠊⡛⢿⣿⣿⣿⣿⡿⣫⢱⢺⡇⡏⣿⣿⣸⡼
⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⡿⠄⣿⣷⣾⡍⣭⣶⣿⣿⡌⣼⣹⢱⠹⣿⣇⣧
⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⠁⣤⣭⣭⡌⢁⣼⣿⣿⣿⢹⡇⣭⣤⣶⣤⡝⡼
⠄⣀⠤⡀⠄⠄⠄⠄⠄⡏⣈⡻⡿⠃⢀⣾⣿⣿⣿⡿⡼⠁⣿⣿⣿⡿⢷⢸
⢰⣷⡧⡢⠄⠄⠄⠄⠠⢠⡛⠿⠄⠠⠬⠿⣿⠭⠭⢱⣇⣀⣭⡅⠶⣾⣷⣶
⠈⢿⣿⣧⠄⠄⠄⠄⢀⡛⠿⠄⠄⠄⠄⢠⠃⠄⠄⡜⠄⠄⣤⢀⣶⣮⡍⣴
⠄⠈⣿⣿⡀⠄⠄⠄⢩⣝⠃⠄⠄⢀⡄⡎⠄⠄⠄⠇⠄⠄⠅⣴⣶⣶⠄⣶

ボ👑⃟༑༑𝐊𝐈𝐍𝐆 𝐒𝐌𝐈𝐋𝐄𝐒 𝐕1✪⃝⚔️ボ*  
𝐂𝐫𝐞𝐚𝐭𝐞𝐝 𝐛𝐲 𝐌𝐫 𝐒𝐦𝐢𝐥𝐞 𝐟𝐨𝐫 𝐩𝐨𝐰𝐞𝐫 & 𝐜𝐨𝐧𝐭𝐫𝐨𝐥
      ${chalk.red.bold("[𝐌𝐎𝐑𝐄 𝐈𝐍𝐅𝐎𝐌𝐀𝐓𝐈𝐎𝐍]")} 
 𝐨𝐰𝐧𝐞𝐫: MR SMILE
 𝐭𝐞𝐥𝐞: @https://t.me/mr_smile_202
 𝐰𝐚: +584261160423
 𝐦𝐲 𝐦𝐞𝐬𝐬𝐚𝐠𝐞:  not created for innocent`));

StartZenn();

// global crash handlers to print colored errors
process.on('uncaughtException', (err) => {
  console.log(chalk.bgRed.white.bold("[UNCAUGHT EXCEPTION]"), err?.stack || err);
});
process.on('unhandledRejection', (reason, p) => {
  console.log(chalk.bgRed.white.bold("[UNHANDLED REJECTION]"), reason);
});
//======================